
WITH ranked_customers AS (
    SELECT 
        c.customer_id,
        c.first_name,
        c.last_name,
        SUM(p.amount) AS total_sales,
        CASE
            WHEN st.rental_id IS NOT NULL THEN 'In-store'
            ELSE 'Online'
        END AS sales_channel
    FROM 
        customer c
    JOIN 
        payment p ON c.customer_id = p.customer_id
    LEFT JOIN 
        store s ON c.store_id = s.store_id
    LEFT JOIN 
        staff st ON s.store_id = st.store_id
    WHERE 
        EXTRACT(YEAR FROM p.payment_date) IN (1998, 1999, 2001)
    GROUP BY 
        c.customer_id, c.first_name, c.last_name, sales_channel
    ORDER BY 
        total_sales DESC
    LIMIT 300
)
SELECT 
    sales_channel,
    COUNT(*) AS customer_count,
    SUM(CASE WHEN sales_channel = 'In-store' THEN total_sales ELSE 0 END) AS in_store_sales,
    SUM(CASE WHEN sales_channel = 'Online' THEN total_sales ELSE 0 END) AS online_sales
FROM 
    ranked_customers
GROUP BY 
    sales_channel;
In this query:

